/* src/config.h.  Generated automatically by configure.  */
/* Define cpu-machine-OS */
#define OS "ALPHA-COMPAQ-VMS"

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the <io.h> header file.  */
#undef HAVE_IO_H

/* Define if you have strdup() */
#define HAVE_STRDUP 1

/* Define if you have utime() */
#undef HAVE_UTIME

/* Define if you have the <utime.h> header file */
#undef HAVE_UTIME_H

/* Define if you have thhe <sys/utime.h> header file */
#undef HAVE_SYS_UTIME_H
